package Codemin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class authDash {
	WebDriver driver;
	public authDash(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="input[placeholder='Email']")
	WebElement username;
	
	@FindBy(css="input[placeholder='Password']")
	 WebElement passwords;
	
	@FindBy(css="input[type='Submit']")
	 WebElement submit;
	
	@FindBy(css=":nth-child(2) > .text-lg")
	WebElement recent30;
	@FindBy(css=".shadow > :nth-child(1) > .text-lg")
	WebElement recent;
	@FindBy(xpath="(//p[contains(text(),'what is the type?')])[1]")
	WebElement clickqs;
	@FindBy(css=".text-lg")
	WebElement clickqsCh;
	@FindBy(xpath="(//input[@value='dLaAtN0CQNOhCEhKu2Xn1A=='])[1]")
	WebElement clickqsedit;
	@FindBy(xpath="(//button[normalize-space()='Update'])[1]")
	WebElement updatbtn;
	@FindBy(css=".text-white > .inline-block")
	WebElement asserofupdate;
	@FindBy(xpath="(//button[normalize-space()='Add'])[1]")
	WebElement addbtn;
	@FindBy(css="button.w-48")
	WebElement cretnw;
	@FindBy(css=".cursor-pointer > .flex > span")
	WebElement menuopt;
	@FindBy(xpath="(//p[normalize-space()='Create Question'])[1]")
	WebElement createquest;
	@FindBy(css="h2[class='text-lg font-medium mr-auto mb-4']")
	WebElement assercreate;
	@FindBy(xpath="(//img[@class='w-auto h-14'])[1]")
	WebElement logoclick;
	@FindBy(xpath="//h2[normalize-space()='Dashboard']")
	WebElement validDashboard;
   @FindBy(xpath="//div[@id='submenu-Questions']")
    WebElement getTexts;
	public  void authlogin(String email,String password) {
		 username.sendKeys(email);
		 passwords.sendKeys(password);
		 submit.click();
		
	}
	public boolean authdash_recent30() {
		return recent.isDisplayed();
	}
	
	
	public boolean authdash_recent() {
		return recent30.isDisplayed();
	}
	public  void authdash_qsClick() {
		clickqs.click();
		
		
		}
	public boolean authDas_qsclickvalid() {
		return clickqsCh.isDisplayed();
	}
	public  void authdash_qsClickedit() {
	
		updatbtn.click();
		asserofupdate.isDisplayed();
		}
	public  void authdash_qsClickeditpublish() {
		
		addbtn.click();
		asserofupdate.isDisplayed();
		
		}
	public  void authdash_qsClickeditcreat() {
		
		cretnw.click();
		
		}
	public void authNeg_editverify() {
		clickqs.click();
	}
	public String authNeg_verifyUrl() {
		return driver.getCurrentUrl();
		
	}
	public String logoClick() {
		logoclick.click();
		return validDashboard.getText();
		 
	}
	public void authneg_hover() {
		menuopt.click();
		
		
	}
	
	public String authneg_hoverContains() {
		menuopt.click();
		return getTexts.getText();
		
	}
	
	

}

package Codemin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Questionpaperpage {

	WebDriver driver;

	public Questionpaperpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[contains(text(),'Question Paper')]")
	WebElement clickoption;

	@FindBy(xpath = "//p[contains(text(),'Create Question Paper')]")
	WebElement createquestionpap;

	@FindBy(css = "#question_paper_name")
	WebElement questionpapname;

	@FindBy(css = "select[name='class']")
	WebElement classdrop;

	@FindBy(css = "select[name='multi_subject']")
	WebElement multisubject;

	@FindBy(css = "select[name='subject']")
	WebElement subjectname;

	@FindBy(css = "input[name='total_score']")
	WebElement totalqscore;

	@FindBy(css = "input[name='tag_name']")
	WebElement tagname;

	@FindBy(css = "input[id='question-no']")
	WebElement totalqs;

	@FindBy(css = "select[name='questionpaper_type']")
	WebElement qspapertype;

	@FindBy(css = "button[type='submit']")
	WebElement createbutton;
	@FindBy(xpath="//div[@class='text-center mb-4 underline text-lg']")
	WebElement verifysection;
	@FindBy(xpath="//div[contains(text(),'please enter the no.of question/Total mark')]")
	WebElement tostifymessage;
	@FindBy(xpath="//label[normalize-space()='Subject']")
	WebElement verifysection_subject;
	@FindBy(xpath="//label[normalize-space()='No of Questions']")
	WebElement verifysection_noQuestion;
	@FindBy(xpath="//label[normalize-space()='Total Mark']")
	WebElement verifysection_totalmark;
	@FindBy(xpath="//label[normalize-space()='Suggested Duration']")
	WebElement verifysection_duration;
	@FindBy(xpath="//button[normalize-space()='Add section']")
	WebElement addsectionbutton;
	@FindBy(xpath="//button[normalize-space()='Add Sub Section']")
	WebElement subsectionadd;
	@FindBy(xpath="//label[normalize-space()='Sub Section Name']")
	WebElement subsectionname;
	@FindBy(xpath="//label[normalize-space()='No.of.questions']")
	WebElement noOFquestion;
	@FindBy(xpath="//label[normalize-space()='Max questions']")
	WebElement maxquestion;
	@FindBy(xpath="//label[normalize-space()='Mark']")
	WebElement mark;
	@FindBy(css="input[id='questions-auto']")
	WebElement QuestionAuto;
	
	@FindBy(xpath="//h2[normalize-space()='Create Question Paper']")
	WebElement createquestionvalidation;
	
	@FindBy(css="input[class*='difficulty-level']")
	WebElement Difficulty;
	
	@FindBy(css="Select[name='state']")
	WebElement levels;
	
	@FindBy(css="input[id='number']")
	WebElement percentage;
	
	@FindBy(xpath="//button[normalize-space()='Add']")
	WebElement addnutton;
	@FindBy(xpath="//button[normalize-space()='Generate']")
	WebElement Genaratebtn;
	
	@FindBy(xpath="//div[@class='Toastify']")
	WebElement tosttext;
	
	@FindBy(css="input[class='pr-2 w-6 h-6 sematic-level']")
	WebElement semantics;
	@FindBy(xpath="//h1[normalize-space()='No Questions Found']")
	WebElement noQuestion;
	@FindBy(xpath="//button[@type='submit']//*[name()='svg']")
	WebElement searchqsbtn;
	@FindBy(xpath="//input[@class='h-6 w-6 header-check']")
	WebElement selectbox;
	@FindBy(xpath="//button[normalize-space()='Add Questions']")
	WebElement addqs;
	@FindBy(xpath="//p[normalize-space()='No questions are added']")
	WebElement addqsValid;
	
	
	@FindBy(xpath="(//input[@type='checkbox'])[6]")
	WebElement selectindqs;
	
	@FindBy(xpath="//h1[contains(text(),'please do remaing questions')]")
	WebElement validpop;
	
	@FindBy(xpath="//button[contains(text(),'Publish')]")
	WebElement publish;
	
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	WebElement Submitmodal;

	@FindBy(xpath="//button[contains(text(),'Create Question')]")
	WebElement CreateQS;
	
	@FindBy(xpath="//select[@id='question_type']")
	WebElement qstype;
	
@FindBy(xpath="//input[@id='score']")
WebElement scorecqs;

@FindBy(css=":nth-child(2) > .pl-3 > .mt-2 > #semantics")
WebElement topicss;
@FindBy(css=":nth-child(3) > .pr-3 > .mt-2 > .w-full")
WebElement SubTopics;
@FindBy(xpath="//div[@class='w-1/3 my-0 text-left px-3']//select[@id='semantics']")
WebElement semanticss;
@FindBy(xpath="(//select[@id='semantics'])[3]")
WebElement diffiCulty;
@FindBy(css="input[name='tags']")
WebElement taGs;
@FindBy(xpath="//input[@value='Create']")
WebElement SUBMIT;
@FindBy(xpath="//input[@id='search-question']")
WebElement searchquestionfield;

@FindBy(css=":nth-child(1) > .fr-box > .fr-wrapper > .fr-element")
WebElement edtques;
@FindBy(css=":nth-child(4) > .fr-box > .fr-wrapper > .fr-element")
WebElement edtans;
@FindBy(css=":nth-child(5) > .fr-box > .fr-wrapper > .fr-element")
WebElement edtans2;
@FindBy(css=":nth-child(6) > .fr-box > .fr-wrapper > .fr-element")
WebElement edtans3;
@FindBy(css=":nth-child(4) > .pr-2")
WebElement edtopt;
@FindBy(css="button[value='Save']")
WebElement edtsav;
@FindBy(xpath="(//button[normalize-space()='Added Question'])[1]")
WebElement addqss;

@FindBy(xpath="//span[normalize-space()='Question paper name is required']")
WebElement verifyerrortext;
@FindBy(xpath="//span[contains(text(),'Total score is required empty or zero values are n')]")
WebElement totalnum;
@FindBy(xpath="//input[@id='question_number']")
WebElement sectionm;
@FindBy(xpath="//input[@id='section_mark']")
WebElement sectiont;
@FindBy(xpath="//button[normalize-space()='Add section']")
WebElement addsection;
@FindBy(css="div[role='alert'] div:nth-child(1)")
WebElement valicheckexceed;
@FindBy(xpath="//div[contains(text(),'Please Enter a Valid Value')]")
WebElement validcheckDiffi;
@FindBy(xpath="//span[normalize-space()='Please enter the type']")
WebElement createqsvalty;
@FindBy(xpath="//span[contains(text(),'Score is required , empty or zero value can not be')]")
WebElement createqsvalsco;
@FindBy(xpath="//span[normalize-space()='Please enter the topic']")
WebElement createqsvaltop;
@FindBy(xpath="//span[normalize-space()='Please enter the subtopic']")
WebElement createqsvalsub;
@FindBy(xpath="//span[normalize-space()='Please enter the semantics']")
WebElement createqsvalsem;
@FindBy(xpath="//p[normalize-space()='There is no Test in this page']")
WebElement notesttext;
@FindBy(xpath="(//*[name()='svg'][@class='w-5 h-5'])[2]")
WebElement test;
@FindBy(xpath="(//p[normalize-space()='Manage Tests'])[1]")
WebElement managetest;
@FindBy(xpath="//div[contains(text(),'Please enter the question')]")
WebElement verifyqsempty;
@FindBy(xpath="//a[normalize-space()='Preview']")
WebElement previewbtn;
@FindBy(xpath="//h2[normalize-space()='Preview']")
WebElement validationpreview;
@FindBy(xpath="//div[@class='button text-center mt-10 flex justify-center']")
WebElement previewfooter;
@FindBy(xpath="//button[normalize-space()='Publish']")
WebElement preview_publish;
@FindBy(xpath="//th[normalize-space()='Subject']")
WebElement previewMODAL_subject;
@FindBy(xpath="//th[normalize-space()='Total Questions']")
WebElement previewMODAL_totalqs;
@FindBy(xpath="//th[normalize-space()='Added Questions']")
WebElement previewMODAL_addedqs;
@FindBy(xpath="//p[@class='text-black-500 warning']")
WebElement previewMODAL_numberofqs;
@FindBy(xpath="//a[normalize-space()='Edit']")
WebElement previewpage_editBtn;
@FindBy(xpath="//input[@id='no_of_questions']")
WebElement noOfQuestionfield;
@FindBy(xpath="//input[@id='max_questions']")
WebElement maxquestionfield;
@FindBy(xpath="//input[@id='mark']")
WebElement markfield;
@FindBy(xpath="//input[@id='tsection_name']")
WebElement sectionname;
@FindBy(xpath="//input[@id='question_number']")
WebElement noofquestionSection;
@FindBy(xpath="//input[@id='section_mark']")
WebElement sectionmarks;
@FindBy(xpath="(//span)[19]")
WebElement subsectiondelete;
@FindBy(xpath="(//span[@class='sprite-image bg-trash_black block'])[1]")
WebElement sectiondeletebtn;

public void subsectiondeletedbtn() {
	subsectiondelete.click();
}
public void sectiondeletedbtn() {
	sectiondeletebtn.click();
}
public void sectionfieldSec(String valuee,String valuee1) {
	noofquestionSection.sendKeys(valuee);
	sectionmarks.sendKeys(valuee1);
	addsectionbutton.click();

	
}

public void sectionfield(String value04,String value,String value2,String value3) {
	
	sectionname.sendKeys(value04);
	noOfQuestionfield.sendKeys(value);
	maxquestionfield.sendKeys(value2);
	markfield.sendKeys(value3);
	subsectionadd.click();
	
}

	public void CreateQuestion(String questionname, String tagnames,String totalnum,String classs,String sub,String subject,String score) {
		clickoption.click();
		createquestionpap.click();
		questionpapname.sendKeys(questionname);
		Select dp1 = new Select(classdrop);
		dp1.selectByValue(classs);
		Select multisubjectdrop = new Select(multisubject);
		multisubjectdrop.selectByValue(sub);
		Select subjectnamedrop = new Select(subjectname);
		subjectnamedrop.selectByVisibleText(subject);
		tagname.sendKeys(tagnames);
		totalqs.sendKeys(totalnum);
		Select drop3 = new Select(qspapertype);
		drop3.selectByValue("Formative");
		totalqscore.sendKeys(score);
		createbutton.click();

	}
	public void CreateMulti(String questionname, String tagnames,String totalnum,String classs,String sub) {
		clickoption.click();
		createquestionpap.click();
		questionpapname.sendKeys(questionname);
		Select dp1 = new Select(classdrop);
		dp1.selectByValue(classs);
		Select multisubjectdrop = new Select(multisubject);
		multisubjectdrop.selectByValue(sub);
		tagname.sendKeys(tagnames);
		totalqs.sendKeys(totalnum);
		Select drop3 = new Select(qspapertype);
		drop3.selectByValue("Formative");
		createbutton.click();

	}
	public boolean CreateMulti_verifySection() {
		verifysection_duration.isDisplayed();
		verifysection_noQuestion.isDisplayed();
		verifysection_subject.isDisplayed();
		verifysection_totalmark.isDisplayed();
		return verifysection.isDisplayed();

	}
	public boolean CreateMulti_SectionADD() throws InterruptedException {
		addsectionbutton.click();
		Thread.sleep(1000);
		return tostifymessage.isDisplayed();

	}
	public boolean CreateMulti_Subsection() {
		subsectionname.click();
		noOFquestion.isDisplayed();
		maxquestion.isDisplayed();
		return mark.isDisplayed();

	}
	public void QuestionGen(String levlname,String percent) {
		QuestionAuto.click();
		Difficulty.click();
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		 
		 
	}
	public void QuestionGenn(String levlname,String percent) {
		
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		 
		 
	}
	public void QuestionGen1(String levlname,String percent) {
		
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		 Genaratebtn.click();
		 tosttext.isEnabled();
		 
	}
	
	public void QuestionSemantics(String levlname,String percent) {
		QuestionAuto.click();
		semantics.click();
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		 Genaratebtn.click();
		 tosttext.isEnabled();
		 
	}
	public void QuestionSemantics2(String levlname,String percent) {
		
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		
		 
	}
	public void instNeg_checkSeman() {
		QuestionAuto.click();
		semantics.click();
		 addnutton.click();
		 
}
	public void instneg_semanticsvalueEmpty(String levlname) {
		QuestionAuto.click();
		semantics.click();
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 addnutton.click();
	}
	public void QuestionSemantics1(String levlname,String percent) {
		QuestionAuto.click();
		semantics.click();
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 percentage.sendKeys(percent);
		 addnutton.click();
		
		 
		 
	}
	public void searchba() {
		searchqsbtn.click();
		
	}
	public boolean stringempty() {
		
		searchquestionfield.sendKeys("ThismyString");
		searchqsbtn.click();
		return noQuestion.isDisplayed();
	}
public boolean addqsempty() {
		
		
		searchqsbtn.click();
		addqs.click();
        return noQuestion.isDisplayed();
	}
	
	public void searchbar() {
		searchqsbtn.click();
		selectbox.click();
		addqs.click();
		//selectindqs.click();
	}
	public void searchbarind() {
		searchqsbtn.click();
		selectbox.click();
		addqs.click();
	}
	public boolean preview() throws InterruptedException {
		Thread.sleep(5000);
		previewbtn.click();
		return validationpreview.isDisplayed();
	}
	public String preview_footercontains() {
		return previewfooter.getText();
	}
	public void previewPage_publish() {
		preview_publish.click();
	}
	public boolean publishpage_modalCONTAINS() {
		previewMODAL_addedqs.isDisplayed();
		previewMODAL_numberofqs.isDisplayed();
		previewMODAL_subject.isDisplayed();
		return previewMODAL_totalqs.isDisplayed();
	}
	public void previewpage_edit() throws InterruptedException {
		previewpage_editBtn.click();
		Thread.sleep(4000);
		createquestionvalidation.isDisplayed();
	}
	
	public void poptextvalid() throws InterruptedException {
		searchqsbtn.click();
		Thread.sleep(2000);
		addqs.click();
		Thread.sleep(2000);
	}
	
	public void creatqspop() throws InterruptedException {
		searchqsbtn.click();
		selectbox.click();
		addqs.click();
		Thread.sleep(3000);
		publish.click();
		Thread.sleep(3000);
		Submitmodal.click();
	}
	public void Createnew(String qstypee, String Scores,String topiCs,String Subtopics,String Semantics,String DiffIcul,String tags,String question,String ans1,String ans2,String ans3) {
		CreateQS.click();
		Select dro =new Select(qstype);
		 dro.selectByValue(qstypee);
		 scorecqs.sendKeys(Scores);
		 Select dro1 =new Select(topicss);
		 dro1.selectByValue(topiCs);
		 Select dro2 =new Select(SubTopics);
		 dro2.selectByValue(Subtopics);
		 Select dro3 =new Select(semanticss);
		 dro3.selectByValue(Semantics);
		 Select dro4 =new Select(diffiCulty);
		 dro4.selectByValue(DiffIcul);
		 taGs.sendKeys(tags);
		 SUBMIT.click();
		 edtques.sendKeys(question);
		 edtans.sendKeys(ans1);
		 edtans2.sendKeys(ans2);
		 edtans3.sendKeys(ans3);
		 edtopt.click();
		 edtsav.click();
		 
	}
	public void createqswithoutqs(String qstypee, String Scores,String topiCs,String Subtopics,String Semantics,String DiffIcul,String tags) throws InterruptedException {
		CreateQS.click();
		Select dro =new Select(qstype);
		 dro.selectByValue(qstypee);
		 scorecqs.sendKeys(Scores);
		 Select dro1 =new Select(topicss);
		 dro1.selectByValue(topiCs);
		 Select dro2 =new Select(SubTopics);
		 dro2.selectByValue(Subtopics);
		 Select dro3 =new Select(semanticss);
		 dro3.selectByValue(Semantics);
		 Select dro4 =new Select(diffiCulty);
		 dro4.selectByValue(DiffIcul);
		 taGs.sendKeys(tags);
		 taGs.sendKeys(Keys.TAB);
		 Thread.sleep(2000);
		 SUBMIT.click();
		 Thread.sleep(3000);
		 edtopt.click();
		 edtsav.click();
		 
	}
	public void createqsValidation(String tags) {
		 taGs.sendKeys(tags);
		 edtsav.click();
		verifyqsempty.isDisplayed();
	}
	public void indvalidNeg() {
		CreateQS.click();
		SUBMIT.click();
		createqsvalty.isDisplayed();
		createqsvalsco.isDisplayed();
		createqsvaltop.isDisplayed();
		createqsvalsub.isDisplayed();
		createqsvalsem.isDisplayed();
		
	}
	public void addedqs() {
		addqss.click();
		addqsValid.isDisplayed();
		
	}
	public boolean instNeg_emptyfield() {
		clickoption.click();
		createquestionpap.click();
		createbutton.click();
		return verifyerrortext.isDisplayed();
		
	}
	public void instNeg_totalnumscore(String questionname,String classs, String sub,String subject,String tagnames) {
		clickoption.click();
		createquestionpap.click();
		questionpapname.sendKeys(questionname);
		Select dp1 = new Select(classdrop);
		dp1.selectByValue(classs);
		Select multisubjectdrop = new Select(multisubject);
		multisubjectdrop.selectByValue(sub);
		Select subjectnamedrop = new Select(subjectname);
		subjectnamedrop.selectByVisibleText(subject);
		tagname.sendKeys(tagnames);
		Select drop3 = new Select(qspapertype);
		drop3.selectByValue("Formative");
		createbutton.click();

	}
	public void instNeg_validationCheck() {
		totalnum.isDisplayed();
	}
	public void instNeg_totalqsCheckWithSection(String questionname, String tagnames,String totalnum,String classs,String sub,String value,String value1) {
		clickoption.click();
		createquestionpap.click();
			questionpapname.sendKeys(questionname);
			Select dp1 = new Select(classdrop);
			dp1.selectByValue(classs);
			Select multisubjectdrop = new Select(multisubject);
			multisubjectdrop.selectByValue(sub);
			tagname.sendKeys(tagnames);
			totalqs.sendKeys(totalnum);
			Select drop3 = new Select(qspapertype);
			drop3.selectByValue("Formative");
			createbutton.click();
			sectionm.sendKeys(value);
			sectiont.sendKeys(value1);
			addsection.click();
				
	}
	public boolean instNeg_validateExceed() throws InterruptedException {
		
		return valicheckexceed.isDisplayed();
	}
	public void testpagemytest() {
		test.click();
		managetest.click();
		notesttext.isDisplayed();
		
	}
	public boolean validatenotest() {
		return notesttext.isDisplayed();

		

	}
	public void instNeg_difficultyEmpty() {
		QuestionAuto.click();
		Difficulty.click();
		 addnutton.click();
	}
	public void instNeg_difficultyhardvalue(String levlname) {
		QuestionAuto.click();
		Difficulty.click();
		 Select drops4 =new Select(levels);
		 drops4.selectByValue(levlname);
		 addnutton.click();
	}
	public boolean instNeg_validationFRdifficul() throws InterruptedException {
		Thread.sleep(2000);
		return valicheckexceed.isDisplayed();
	}

}

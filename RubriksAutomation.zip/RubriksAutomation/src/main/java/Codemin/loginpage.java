package Codemin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginpage {
	WebDriver driver;
	public loginpage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="input[placeholder='Email']")
	WebElement username;
	
	@FindBy(css="input[placeholder='Password']")
	 WebElement passwords;
	
	@FindBy(css="input[type='Submit']")
	 WebElement submit;
	
	@FindBy(xpath="//nav[@class='flex flex-1 hidden w-full h-16 space-x-1 md:flex px-10']")
	WebElement header;
	
	@FindBy(xpath="(//span[@class='w-[434px] mb-2 -mt-3 text-red-500 text-sm'])[1]")
	WebElement emailval;
	@FindBy(xpath="(//span[@class='w-[434px] mb-2 mt-2 text-red-500 text-sm'])[1]")
	WebElement passwordval;
	@FindBy(xpath="(//div[@class='Toastify'])[1]")
	WebElement invalid;
	
	
	public  void instructorlogin(String email,String password) {
		 username.sendKeys(email);
		 passwords.sendKeys(password);
		 submit.click();
		
	}
	public  void instructorloginN() {
		 
		 submit.click();
		
	}
	
	
	public void loadUrl() {
		driver.get("https://rubriks-int.web.app/");
	}
	public void loadUrlAsses() {
		driver.get("https://rubriks-assessment.web.app/");
	}
	public boolean empty() {
		return emailval.isDisplayed();
	}
	public boolean Empty() {
		return passwordval.isDisplayed();
	}
	public boolean invalid() {
		return invalid.isDisplayed();
	}
	


}

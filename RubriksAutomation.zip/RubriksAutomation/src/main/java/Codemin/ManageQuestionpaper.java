package Codemin;


import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ManageQuestionpaper {
	WebDriver driver;
	public ManageQuestionpaper(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//span[contains(text(),'Question Paper')]")
	WebElement clickoption;
	@FindBy(xpath="(//p[normalize-space()='Manage Question Paper'])[1]")
	WebElement manageqs;
	@FindBy(xpath="//button[@type='submit']//*[name()='svg']")
	WebElement searchqsbtn;
	@FindBy(xpath="//input[@class='h-6 w-6 header-check']")
	WebElement selectbox;
	@FindBy(xpath="//button[normalize-space()='Add Questions']")
	WebElement addqs;
	
	@FindBy(css=".text-lg.font-medium.mr-auto.mt-4")
	 WebElement validmanage;
	
	@FindBy(xpath="//button[normalize-space()='View']")
	 WebElement viewbtn;
	
	@FindBy(css="th:nth-child(6)")
	WebElement edit;
	@FindBy(xpath="(//span)[7]")
	WebElement editbtn;
	@FindBy(xpath="(//button[contains(text(),'Publish')])[1]")
	WebElement Publishbtn;
	@FindBy(xpath="//span[normalize-space()='Click here to review and publish']")
	WebElement clickmodal;
	@FindBy(xpath="(//h2[normalize-space()='Create Question Paper'])[1]")
	WebElement validcreat;
	@FindBy(xpath="//button[contains(text(),'Publish')]")
	WebElement publish;
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	WebElement Submitmodal;
	@FindBy(xpath="(//a[normalize-space()='Assign'])[1]")
	WebElement verifybtn;
	@FindBy(xpath="(//h3[normalize-space()='Test'])[1]")
	WebElement validtest;
	@FindBy(xpath="(//input[@id='test-name'])[1]")
	WebElement testname;
	@FindBy(xpath="(//input[@class='h-6 w-6'])[1]")
	WebElement section;
	@FindBy(xpath="(//p)[8]")
	WebElement instruc;
	@FindBy(xpath="(//button[normalize-space()='Assign'])[1]")
	WebElement assignbtn;
	@FindBy(xpath="//div[contains(@class,'Toastify')]")
	WebElement tostmess;
	@FindBy(xpath="(//*[name()='svg'][@class='w-5 h-5'])[2]")
	WebElement test;
	@FindBy(xpath="(//p[normalize-space()='Manage Tests'])[1]")
	WebElement managetest;
	@FindBy(xpath="(//h2[normalize-space()='Assigned tests'])[1]")
	WebElement validtestpage;
	@FindBy(xpath="(//input[@id='all'])[1]")
	WebElement allfilt;
	@FindBy(xpath="(//input[@id='schedule'])[1]")
	WebElement scdhule;
	@FindBy(xpath="(//input[@id='open'])[1]")
	WebElement open;
	@FindBy(xpath="(//input[@id='closed'])[1]")
	WebElement closed;
	@FindBy(xpath="(//label[normalize-space()='My Tests'])[1]")
	WebElement mytest;
	@FindBy(xpath="(//select[@name='class'])[1]")
	WebElement classfil;
	@FindBy(xpath="(//select[@name='subject'])[1]")
	WebElement cllss;
	@FindBy(xpath="(//input[@name='from_date'])[1]")
	WebElement date;
	@FindBy(xpath="//*[@id=\"root\"]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/button[1]")
	WebElement fromdate;
	@FindBy(xpath="(//input[@id='question-no'])[1]")
	WebElement backspace;
	@FindBy(xpath="//*[@id=\"root\"]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div/button[1]")
	WebElement todate;
	@FindBy(xpath="//button[normalize-space()='View']")
	WebElement viewbuttonn;
	@FindBy(css="tbody tr:nth-child(2) td:nth-child(7) a:nth-child(1)")
	WebElement assignpage;
	@FindBy(xpath="//button[contains(text(),'Publish')]")
	WebElement publishPAge;
	@FindBy(xpath="//input[@name='end_date']")
	WebElement todated;
	@FindBy(xpath="(//p[normalize-space()='No data Found'])[1]")
	WebElement validatetodate;
	@FindBy(css="#striped-rows-table > div > div > table > tbody > tr > td:nth-child(7) > a")
	List <WebElement> categories;
	public void manage_todated(String value) {
		todated.sendKeys(value);
	}
	public boolean manage_validationtoDate() {
		return validatetodate.isDisplayed();
	}
	public void manage_view() {
		viewbuttonn.click();
	}
	public void manage_assignbutton() {
		
		try {
			categories.stream().filter(ele->ele.getText().equalsIgnoreCase("Assign")).forEach(ele -> ele.click());

		} catch (StaleElementReferenceException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public void manage_publishbutton() {
		publishPAge.click();
	}
	public  void Manageqspape(String classn) {
		clickoption.click();
		manageqs.click();
		Select drops4 =new Select(classfil);
		 drops4.selectByValue(classn);
		viewbtn.click();
		}
	public  void ManageqspapeSub(String value) {
		clickoption.click();
		manageqs.click();
		Select drops4 =new Select(cllss);
		 drops4.selectByValue(value);
		viewbtn.click();
		}
	public  void Manageqspapedate(String Date) {
		clickoption.click();
		manageqs.click();
		date.sendKeys(Date);
		viewbtn.click();
		}
	public  void Manageqspaper() {
		clickoption.click();
		manageqs.click();
		viewbtn.click();
		}
	public void managevalidedit() {
		edit.isDisplayed();
		editbtn.click();
		
	}
	public void publishbtn() {
		Publishbtn.click();
		clickmodal.click();
		validcreat.isDisplayed();
		
	}
	public void publishAsASSIGN() throws InterruptedException {
		Publishbtn.click();
		clickmodal.click();
		backspace.sendKeys(Keys.BACK_SPACE);
		searchqsbtn.click();
		selectbox.click();
		addqs.click();
		Thread.sleep(10000);
		publish.click();
		Submitmodal.click();
		viewbtn.click();
		verifybtn.getText();
	
		}
	public void assignpage(String testnam,String instruction) {
		verifybtn.click();
		validtest.isDisplayed();
		testname.sendKeys(testnam);
		section.click();
		instruc.sendKeys(instruction);
		assignbtn.click();
		tostmess.getText();
		
	}
	public void instneg_assignpage(String instruction) {
		verifybtn.click();
		validtest.isDisplayed();
		section.click();
		instruc.sendKeys(instruction);
		assignbtn.click();
		tostmess.getText();
		
	}
	public void instneg_withoutsec(String testnam,String instruction) {
		verifybtn.click();
		validtest.isDisplayed();
		testname.sendKeys(testnam);
		instruc.sendKeys(instruction);
		assignbtn.click();
		tostmess.getText();
		
	}
	public void instneg_withoutinstr(String testnam) {
		verifybtn.click();
		validtest.isDisplayed();
		testname.sendKeys(testnam);
		section.click();
		assignbtn.click();
		tostmess.getText();
		
	}
	public void instNeg_withoutdate(String testnam,String instruction) {
		verifybtn.click();
		validtest.isDisplayed();
		testname.sendKeys(testnam);
		section.click();
		instruc.sendKeys(instruction);
		assignbtn.click();
		fromdate.click();
		tostmess.getText();
	}
	public void instNeg_withoutTOdate(String testnam,String instruction) {
		verifybtn.click();
		validtest.isDisplayed();
		testname.sendKeys(testnam);
		section.click();
		instruc.sendKeys(instruction);
		assignbtn.click();
		todate.click();
		tostmess.getText();
	}
	
	public void testpage() {
		test.click();
		managetest.click();
		validtestpage.isDisplayed();
		
	}
	public void testpageAll() {
		test.click();
		managetest.click();
		allfilt.click();
		
	}
	public void testpagescdhule() {
		test.click();
		managetest.click();
		scdhule.click();
		
	}
	public void testpageopen() {
		test.click();
		managetest.click();
		open.click();
		
	}
	public void testpageclosed() {
		test.click();
		managetest.click();
		closed.click();
		
	}
	public void testpagemytest() {
		test.click();
		managetest.click();
		mytest.click();
		
	}
	
	
	
	public String Valid() {
		return validmanage.getText();
	}
	


}

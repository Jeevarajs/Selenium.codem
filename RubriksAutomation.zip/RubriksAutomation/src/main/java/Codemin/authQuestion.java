package Codemin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class authQuestion {
	WebDriver driver;
	public authQuestion(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="input[placeholder='Email']")
	WebElement username;
	
	@FindBy(css="input[placeholder='Password']")
	 WebElement passwords;
	
	@FindBy(css="input[type='Submit']")
	 WebElement submit;
	
	@FindBy(css=":nth-child(2) > .text-lg")
	WebElement recent30;
	@FindBy(css=".shadow > :nth-child(1) > .text-lg")
	WebElement recent;
	@FindBy(xpath="(//p[normalize-space()='mcq?'])[1]")
	WebElement clickqs;
	@FindBy(css=".text-lg")
	WebElement clickqsCh;
	@FindBy(xpath="(//input[@value='dLaAtN0CQNOhCEhKu2Xn1A=='])[1]")
	WebElement clickqsedit;
	@FindBy(xpath="(//button[normalize-space()='Update'])[1]")
	WebElement updatbtn;
	@FindBy(css=".text-white > .inline-block")
	WebElement asserofupdate;
	@FindBy(xpath="(//button[normalize-space()='Add'])[1]")
	WebElement addbtn;
	@FindBy(css="button.w-48")
	WebElement cretnw;
	@FindBy(css=".cursor-pointer > .flex > span")
	WebElement menuopt;
	@FindBy(xpath="(//p[normalize-space()='Create Question'])[1]")
	WebElement createquest;
	@FindBy(css="h2[class='text-lg font-medium mr-auto mb-4']")
	WebElement assercreate;
	@FindBy(xpath="//label[normalize-space()='Class']")
	WebElement containclass;
	@FindBy(xpath="//label[normalize-space()='Subject']")
	WebElement containsSubject;
	@FindBy(xpath="//label[normalize-space()='Question Type']")
	WebElement conatinsqstypr;
	@FindBy(xpath="//label[normalize-space()='Score']")
	WebElement conatinsscore;
	@FindBy(xpath="//label[normalize-space()='Topics']")
	WebElement conatinstopics;
	@FindBy(xpath="//label[normalize-space()='Sub Topics']")
	WebElement conatinssubtopic;
	@FindBy(xpath="//label[normalize-space()='Semantics']")
	WebElement conatinsseman;
	@FindBy(css="select[name='class']")
	WebElement clas;
	@FindBy(css="select[name='subject']")
	WebElement subj;
	@FindBy(css="select[name='question_type']")
	WebElement typpe;
	@FindBy(css="input[name='score']")
	WebElement scor;
	@FindBy(css="input[name='source']")
	WebElement sour;
	@FindBy(css="select[name='topic']")
	WebElement topi;
	@FindBy(css="select[name='sub_topic']")
	WebElement subtop;
	@FindBy(css="select[name='semantics']")
	WebElement semant;
	@FindBy(css="select[name='difficulty']")
	WebElement diffic;
	@FindBy(css="input[name='tags']")
	WebElement tags;
	@FindBy(css="input[value='Create']")
	WebElement createbtn;
	@FindBy(css=":nth-child(1) > .fr-box > .fr-wrapper > .fr-element")
	WebElement editorqs;
	@FindBy(xpath="(//input[contains(@type,'number')])[2]")
	WebElement numeditor1;
	@FindBy(xpath="(//input[contains(@type,'number')])[3]")
	WebElement numeditor2;
	@FindBy(xpath="(//input[contains(@type,'number')])[4]")
	WebElement numeditor3;
	@FindBy(css=":nth-child(4) > .fr-box > .fr-wrapper > .fr-element")
	WebElement editorans;
	@FindBy(css=":nth-child(5) > .fr-box > .fr-wrapper > .fr-element")
	WebElement editorans1;
	@FindBy(css=":nth-child(6) > .fr-box > .fr-wrapper > .fr-element")
	WebElement editorans2;
	@FindBy(css=":nth-child(4) > .pr-2")
	WebElement option;
	@FindBy(xpath="//*[@id=\"root\"]/div/div/div[2]/div/div[2]/div/div[3]/div/div/div[3]/div[1]/input")
	WebElement optionnum;
	@FindBy(xpath="//nav[contains(@aria-label,'Page navigation')]")
	WebElement paginavi;
	@FindBy(xpath="//span[normalize-space()='»']")
	WebElement pagnavigate;
	@FindBy(css="button[value='Save']")
	WebElement createbt;
	@FindBy(xpath="(//div[@class='bg-white'])[2]")
	WebElement Asseqs;
	@FindBy(css="[value='Save and Publish']")
	WebElement edit;
	@FindBy(xpath="(//input[@id='add-hint'])[1]")
	WebElement hintche;
	@FindBy(xpath="//div[@class='fr-wrapper show-placeholder']//p")
	WebElement hinttext;
	@FindBy(xpath="(//p[normalize-space()='Manage Question'])[1]")
	WebElement manage;
	@FindBy(xpath="(//h2[normalize-space()='Manage Questions'])[1]")
	WebElement assemange;
	@FindBy(css= ".mt-2 select.w-full[data-placeholder='Select class']")
	WebElement claassma;
	@FindBy(css="select[name='subject']")
	WebElement subjmanag;
	@FindBy(xpath="(//button[normalize-space()='Search'])[1]")
	WebElement searchbbtn;
	@FindBy(xpath="(//span[@title='Edit'])[1]")
	WebElement editbbtn;
	@FindBy(css="input[value='all']")
	WebElement aalqs;
	@FindBy(xpath="//label[normalize-space()='Saved']")
	WebElement savqs;
	@FindBy(xpath="(//span[@class='sprite-image bg-clone_black block'])[1]")
	WebElement Dupli;
	@FindBy(xpath="//span[normalize-space()='Please enter the class']")
	WebElement errotext;
	@FindBy(xpath="//span[normalize-space()='Please enter the subject']")
	WebElement errortext_subject;
	@FindBy(xpath="//span[normalize-space()='Please enter the type']")
	WebElement errortext_type;
	@FindBy(xpath="//span[contains(text(),'Score is required , empty or zero value can not be')]")
	WebElement errortext_score;
	@FindBy(xpath="//span[normalize-space()='Please enter the topic']")
	WebElement errortext_topic;
	@FindBy(xpath="//span[normalize-space()='Please enter the subtopic']")
	WebElement errortext_subtopic;
	@FindBy(xpath="//span[normalize-space()='Please enter the semantics']")
	WebElement errortext_semantics;
	@FindBy(xpath="//input[@value='Create']")
	WebElement createbtnn;
	@FindBy(xpath="//input[@id='score']")
	WebElement scorefield;
	@FindBy(xpath="(//div[contains(text(),'Please Enter a class & Subject')])[1]")
	WebElement alertmessage;
	@FindBy(xpath="//button[normalize-space()='Search']")
	WebElement searchbtnm;
	@FindBy(xpath="//input[@id='Apply']")
	WebElement apply;
	@FindBy(xpath="//h1[normalize-space()='No Question']")
	WebElement noques;
	@FindBy(xpath="//input[@id='Medium']")
	WebElement difficulty;
	
	public  boolean authcreateQuestion() {
		menuopt.click();
		createquest.click();
		return assercreate.isDisplayed();
		
		}
	public void pagnavigation() {
		paginavi.isDisplayed();
		
	}
	public void pagnaviget(String value) {
		String web=pagnavigate.getCssValue(value);
		System.out.println(web);
	}
	public boolean containsfrcreateqs() {
		containclass.isDisplayed();
		conatinsqstypr.isDisplayed();
		conatinsscore.isDisplayed();
		conatinsseman.isDisplayed();
		conatinssubtopic.isDisplayed();
		conatinstopics.isDisplayed();
		return containsSubject.isDisplayed();
	}
	public  void authcreateQuestionMcq(String value,String value1,String value2,String cha,String value3,
			String value4,String value5,String value6,String cha1) {
		Select dropdw=new Select(clas);
		dropdw.selectByValue(value);
		Select dropdw1=new Select(subj);
		dropdw1.selectByValue(value1);
		Select dropdw2=new Select(typpe);
		dropdw2.selectByValue(value2);
		scor.sendKeys(cha);
		Select dropdw3=new Select(topi);
		dropdw3.selectByValue(value3);
		Select dropdw4=new Select(subtop);
		dropdw4.selectByValue(value4);
		Select dropdw5=new Select(semant);
		dropdw5.selectByValue(value5);
		Select dropdw6=new Select(diffic);
		dropdw6.selectByValue(value6);
		tags.sendKeys(cha1);
		createbtn.click();
		
}
	public void authcreateQuestionmcqtype(String Text,String Text1,String Text2,String Text3) {
		editorqs.sendKeys(Text);
		editorans.sendKeys(Text1);
		editorans1.sendKeys(Text2);
		editorans2.sendKeys(Text3);
		option.click();
		createbt.click();
		
	}
	public void authcreateQuestionNUMtype(String Text,String Text1,String Text2,String Text3) {
		editorqs.sendKeys(Text);
		numeditor1.sendKeys(Text1);
		numeditor2.sendKeys(Text2);
		numeditor3.sendKeys(Text3);
		optionnum.click();
		createbt.click();
		
	}
	public void tagclick(String value) {
		tags.sendKeys(value);
		createbt.click();
	}
	public boolean authcreateQuestionmcqtypeAsser() {
		return Asseqs.isDisplayed();
		
		
	}
	public void authcreatequestionedit() {
		edit.click();
		createbt.click();
		
	}
	public void authcreatequestioncreatenw() {
		cretnw.click();
		
	}
	public void hint(String Text) {
		hintche.click();
		hinttext.sendKeys(Text);
	}
	public void manageqs() {
		menuopt.click();
		manage.click();
		searchbbtn.click();
	}
	public boolean manage_valid() {
		return assemange.isDisplayed();
	}
	public void manage_claass(String value5,String value) {
		Select dropdw5=new Select(claassma);
		dropdw5.selectByValue(value5);
		Select dropdw=new Select(subjmanag);
		dropdw.selectByValue(value);
		searchbbtn.click();
		
	}
	public void manage_edit() {
		editbbtn.click();
	}
	public boolean checkasser() {
		return assercreate.isDisplayed();
	}
	public void manage_allquestion() {
		aalqs.click();
	}
	public void manage_savedquestion() {
		savqs.click();
		savqs.click();

	}
	public void manage_duplicatquestion() {
		Dupli.click();
	}
	public boolean authNeg_emptydataError() {
		
		return errotext.isDisplayed();
	}
	public boolean authneg_errorempty() {
		errortext_score.isDisplayed();
		errortext_semantics.isDisplayed();
		errortext_subject.isDisplayed();
		errortext_subtopic.isDisplayed();
		errortext_topic.isDisplayed();
		return errortext_type.isDisplayed();
	}
	public  void authneg_createQuestion() throws InterruptedException {
		menuopt.click();
		createquest.click();
		Thread.sleep(2000);
		createbtnn.click();
		
		}
	public String authneg_clicksubject() {
		return subj.getText();
	
	}
	public boolean authneg_checkscorefield(String text) {
		scorefield.sendKeys(text);
	    createbtnn.click();
	    return errortext_score.isDisplayed();
		
		
	}
	public void authneg_tagsalpha(String text) {
		tags.sendKeys(text);
	}
	public void authneg_tagsalpha1(String text) {
		tags.sendKeys(text);
		tags.sendKeys(Keys.TAB);
	}
	
	public boolean authneg_manageEmptydata() {
		return alertmessage.isDisplayed();
	}
	public void authneg_checkmanagaEmpty(String value) {
		
	
	Select dropdw5=new Select(claassma);
	dropdw5.selectByValue(value);
	
	searchbtnm.click();
	}
	public void authneg_checkmanagaEmptyclass(String value) {
		
		
		Select dropdw=new Select(subjmanag);
		dropdw.selectByValue(value);
		
		searchbtnm.click();
		}
	public void authneg_checkwithfilter(String value,String value1) {
		Select dropdw5=new Select(claassma);
		dropdw5.selectByValue(value);
		Select dropdw=new Select(subjmanag);
		dropdw.selectByValue(value1);
		apply.click();
		searchbtnm.click();	
	}
	public boolean authneg_noquestionvalidation() {
		return noques.isDisplayed();
	}
	public void authneg_checkwithfilterdifficulty(String value,String value1) {
		Select dropdw5=new Select(claassma);
		dropdw5.selectByValue(value);
		Select dropdw=new Select(subjmanag);
		dropdw.selectByValue(value1);
		difficulty.click();
		searchbtnm.click();	
	}
	
	

}

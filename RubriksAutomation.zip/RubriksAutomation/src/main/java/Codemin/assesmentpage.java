package Codemin;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class assesmentpage {
	WebDriver driver;
	public assesmentpage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(css=".preview table")
	WebElement table;
	
	@FindBy(xpath="(//h2[normalize-space()='Dashboard'])[1]")
	 WebElement dashbordvali;
	@FindBy(css=":nth-child(1) > #movie0 > .modal-overlay")
	WebElement testassig;
	@FindBy(css="a[href='assesment']")
	WebElement taketest;
	@FindBy(xpath="//a[normalize-space()='TAKE TEST']")
	WebElement taketestt;
	@FindBy(xpath="//*[@id='movie0']/div[3]/div")
	WebElement moreinfo;
	@FindBy(xpath="//button[normalize-space()='Start']")
	WebElement starttest;
	@FindBy(css="div.p-6 div.shadow button")
	WebElement CONtest;
	@FindBy(xpath="(//a[normalize-space()='My Tests'])")
	WebElement myTEst;
	@FindBy(xpath="(//h2[normalize-space()='My Test'])")
	WebElement validmytest;
	@FindBy(xpath="//button[normalize-space()='Start']")
	WebElement takeTesT;
	@FindBy(css=".w-80")
	WebElement checkfied_name;
	@FindBy(css="thead > .text-left > :nth-child(3)")
	WebElement checkfied_tag;
	@FindBy(css="thead > .text-left > :nth-child(5)")
	WebElement checkfied_date;
	@FindBy(css=":nth-child(1) > :nth-child(7) > .btn > a")
	WebElement mytest_taketest;
	@FindBy(xpath="(//a[normalize-space()='SHOW RESULTS'])")
	WebElement mytest_validateresult;
	@FindBy(xpath="(//h2[normalize-space()='Test Summary']")
	WebElement showresultpage;
	@FindBy(xpath="//th[normalize-space()='Total Questions']")
	WebElement result_totalquestion;
	@FindBy(xpath="(//th[contains(text(),'Time Taken')])[1]")
	WebElement result_timetaken;
	@FindBy(xpath="//th[normalize-space()='Final Score']")
	WebElement result_finalscore;
	@FindBy(xpath="//th[normalize-space()='Section Name']")
	WebElement result_sectionname;
	@FindBy(xpath="//th[normalize-space()='No of Questions']")
	WebElement result_noofquestion;
	@FindBy(xpath="//th[normalize-space()='Answered']")
	WebElement result_answered;
	@FindBy(xpath="//th[normalize-space()='Not answered']")
	WebElement result_notanswer;
	@FindBy(xpath="//th[normalize-space()='Marked for Review']")
	WebElement result_markfrrevie;
	@FindBy(xpath="(//th[contains(text(),'Time Taken')])[2]")
	WebElement result_timetaken2;
	
	
	@FindBy(xpath="(//button[normalize-space()='Continue Test'])[1]")
	WebElement continuetest;
	@FindBy(xpath="//*[@id='root']/div/div/div[2]/div[2]/div/div[3]/div/div/div/div[1]/div[1]/h1")
	WebElement title;
	@FindBy(xpath="(//h3[normalize-space()='Section A'])")
	WebElement section;
	@FindBy(xpath="(//input[@id='unanswered'])")
	WebElement unasnwerbtn;
	@FindBy(xpath="(//input[@id='mark-review'])")
	WebElement MarkfrReview;
	@FindBy(xpath="(//input[@id='all-test'])[1]")
	WebElement all;
	@FindBy(xpath="(//input[@value='lpj5bgx0QcOlm+q5XuUDsQ==']")
	WebElement answer1;
	@FindBy(xpath="(//button[normalize-space()='Save'])[1]")
	WebElement savebtn;
	@FindBy(xpath="(//button[normalize-space()='Save & Mark For Review'])")
	WebElement markbtn;
	@FindBy(xpath="(//button[normalize-space()='Un-select'])")
	WebElement unselectbtn;
	@FindBy(xpath="//h3[normalize-space()='Instruction']")
	WebElement instruction;
	@FindBy(xpath="(//*[name()='svg'][@id='Layer_1'])")
	WebElement nextslidebtn;
	@FindBy(xpath="(//*[name()='svg'][@id='Capa_1'])[1]")
	WebElement backslidebtn;
	@FindBy(xpath="(//*[name()='path'][@id='a'])")
	WebElement sectionmenu;
	@FindBy(xpath="(//div[contains(@class,'flex justify-center p-5 sub-level')])[1]")
	WebElement subsection;
	@FindBy(xpath="(//button[normalize-space()='2'])[1]")
	WebElement pagin;
	@FindBy(css="div.button > button.w-auto")
	WebElement submitbutton;
	@FindBy(xpath="(//button[normalize-space()='Yes'])[1]")
	WebElement yesbttn;
	@FindBy(xpath="(//button[normalize-space()='No'])[1]")
	WebElement nobtn;
	@FindBy(xpath="//tbody/tr[1]/td[1]/span[1]")
	WebElement navig;
	@FindBy(xpath="//tbody/tr[1]/td[1]/span[1]")
	WebElement naviunas;
	@FindBy(xpath="//tbody/tr[1]/td[1]/span[1]")
	WebElement navimark;
	@FindBy(xpath="(//h2[normalize-space()='Congratulations! Your test has been submitted'])")
	WebElement verifytext;
	@FindBy(xpath="(//a[normalize-space()='Practice Tests'])[1]")
	WebElement clickpractie;
	@FindBy(xpath="(//h2[normalize-space()='Practice Test'])[1]")
	WebElement validpract;
	@FindBy(css=".mt-2 > .w-full")
	WebElement clickpract;
	@FindBy(xpath="(//button[normalize-space()='Create Test'])[1]")
	WebElement createe;
	@FindBy(xpath="(//p[@class='text-green-500'])[1]")
	WebElement checktext;
	@FindBy(xpath="(//p[@class='text-green-500'])[1]")
	WebElement clickButton;
	@FindBy(xpath="(//*[name()='path'][@fill-rule='evenodd'])[2]")
	WebElement logout;
	@FindBy(css=".text-red-500.text-center")
	WebElement errorText;
	@FindBy(xpath="//button[normalize-space()='Un-select']")
	WebElement checkunselect;
	@FindBy(css=":nth-child(1) > input.w-6")
	WebElement selectanswer1;
	@FindBy(xpath="//div[normalize-space()='No.Of Questions']")
	WebElement check1;
	@FindBy(xpath="//button[normalize-space()='Create Test']")
	WebElement check2;
	@FindBy(xpath="//p[@class='test-name text-white text-base']")
	WebElement testdetails;
	@FindBy(xpath="//p[@class='duration text-white text-base']")
	WebElement testduration;
	@FindBy(xpath="//p[normalize-space()='Subject']")
	WebElement more_subject;
	@FindBy(xpath="//p[normalize-space()='Test Name']")
	WebElement more_testname;
	@FindBy(xpath="//p[@class='mr-2 text-sm text-gray-600']")
	WebElement more_duration;
	@FindBy(xpath="//p[normalize-space()='Tag Name']")
	WebElement more_tagname;
	@FindBy(xpath="//p[normalize-space()='class']")
	WebElement more_class;
	@FindBy(xpath="//p[normalize-space()='Type']")
	WebElement more_type;
	@FindBy(xpath="//p[normalize-space()='No.of Questions']")
	WebElement more_question;
	@FindBy(xpath="//p[normalize-space()='Total marks']")
	WebElement more_marks;
	@FindBy(xpath="//th[normalize-space()='S.NO']")
	WebElement mytest_sno;
	@FindBy(xpath="//th[contains(@class,'border-b-2 px-5 py-3 whitespace-nowrap w-80')]")
	WebElement mytest_testname;
	@FindBy(xpath="//th[normalize-space()='Tag Name']")
	WebElement mytest_tagname;
	@FindBy(xpath="//th[normalize-space()='Duration']")
	WebElement mytest_duration;
	@FindBy(xpath="//th[normalize-space()='Start Date']")
	WebElement mytest_startdate;
	@FindBy(xpath="//th[normalize-space()='Expiry Date']")
	WebElement mytest_expirydate;
	@FindBy(xpath="//th[normalize-space()='Action']")
	WebElement mytest_action;
	@FindBy(linkText="TAKE TEST")
	WebElement takeTEST;
	@FindBy(xpath="//a[normalize-space()='CONTINUE TEST']")
	WebElement contiuetest;
	@FindBy(css="a[href='/assesment']")
	WebElement taketestpage;
	
	public boolean mytestcontains() {
		mytest_action.isDisplayed();
		mytest_duration.isDisplayed();
		mytest_expirydate.isDisplayed();
		mytest_sno.isDisplayed();
		mytest_startdate.isDisplayed();
		mytest_tagname.isDisplayed();
		return mytest_testname.isDisplayed();
	}
	
	public boolean moreinfovalidation() {
		more_class.isDisplayed();
		more_duration.isDisplayed();
		more_marks.isDisplayed();
		more_question.isDisplayed();
		more_subject.isDisplayed();
		more_tagname.isDisplayed();
		more_testname.isDisplayed();
		return more_type.isDisplayed();
	}
	
	public void cauroseldetails() {
		testduration.isDisplayed();
		testdetails.isDisplayed();
	}
	public void verifyMarkfrReview() throws InterruptedException {
		Thread.sleep(5000);
		selectanswer1.click();
		markbtn.click();
		MarkfrReview.click();
		Thread.sleep(3000);
		checkunselect.click();
		
	}
	public boolean checkfrpract() {
		check1.isDisplayed();
		return check2.isEnabled();
	}
	public boolean verifymarkfrthrowError() throws InterruptedException {
		Thread.sleep(3000);
		markbtn.click();
		return errorText.isDisplayed();
		
	}
	
	public boolean assesm_UnSelectBtn() {
		return checkunselect.isDisplayed();
	}
	public void assesm_Dashboard() {
		dashbordvali.isDisplayed();
	}
	public void assesm_recentscore() {
		table.isDisplayed();
	}
	public void assesm_testAssig() throws InterruptedException {
		Actions action = new Actions(driver);
		action.moveToElement(testassig).click().build().perform();
		
	}
	public void assesm_taketest() throws InterruptedException {
		Thread.sleep(3000);
        taketestpage.click();
		Thread.sleep(3000);
	
	}
	public void assesm_continuetest() throws InterruptedException {
		continuetest.click();
		Thread.sleep(4000);
	}
	public void assesm_moreinfo() {
		moreinfo.click();
	}
	public void assesm_starttest() {
		starttest.click();
	}
	public void assesmm_continue() throws InterruptedException {
		Thread.sleep(3000);
		continuetest.click();
		
	}
	public void assesm_CONTtest() throws InterruptedException {
		Thread.sleep(3000);
		CONtest.click();
	}
	public void assesm_MyTest() {
		myTEst.click();
	}
	public boolean assesm_validatemytest()
	{
		return validmytest.isDisplayed();
	}
	public void assesm_takeTEST() {
		takeTesT.click();
	}
	public boolean assesm_mytest_Ctest() throws InterruptedException {
		Thread.sleep(3000);
		checkfied_name.isDisplayed();
		checkfied_tag.isDisplayed();
		return checkfied_date.isDisplayed();
	}
	public void assesm_mytestpage_taketest() {
		mytest_taketest.click();
	}
	public void assesm_mytestpage_validateresult() {
		mytest_validateresult.isDisplayed();
	}
	public void assesm_mytestpage_clickresult() throws InterruptedException {
		mytest_validateresult.click();
		
	}
	
	public boolean assesm_showResultpage() throws InterruptedException {
		result_answered.isDisplayed();
		result_finalscore.isDisplayed();
		result_markfrrevie.isDisplayed();
		result_noofquestion.isDisplayed();
		result_notanswer.isDisplayed();
		result_sectionname.isDisplayed();
		result_timetaken.isDisplayed();
		result_timetaken2.isDisplayed();
		return result_totalquestion.isDisplayed();
		
	}
	public void assesm_continuebutton() {
		continuetest.click();
	}
	public boolean assesm_titleofpage() {
		return title.isDisplayed();
	}
	public boolean assesm_sectionname() {
		return section.isDisplayed();
	}
	public void assesm_unanswerbtn() {
		unasnwerbtn.click();
	}
	public void assesm_markfrREview() {
		MarkfrReview.click();
	}
	public void assesm_alltest() {
		all.click();
	}
	public void assesm_answer() throws InterruptedException {
		selectanswer1.click();
		savebtn.click();
		Thread.sleep(3000);
	}
	public void assesm_answer1() {
		//answer1.click();
		markbtn.click();
	}
	public void assesm_unselect() throws InterruptedException {
		Thread.sleep(5000);
		selectanswer1.click();
		unselectbtn.click();
	}
	public boolean assesm_instruction() {
		return instruction.isDisplayed();
	}
	public void assesm_nextbtnslide() {
		nextslidebtn.click();
	}
	public void assesm_backbtnslide() {
		backslidebtn.click();
	}
	public void susection() throws InterruptedException {
		Thread.sleep(3000);
		sectionmenu.click();
		subsection.click();
		
	}
	public void pagination() {
		pagin.click();
	}
	public void submitbtn() {
		submitbutton.click();
	}
	public void yesbtn() {
		yesbttn.click();
	}
	public void nobtn(){
		nobtn.click();
	}
	public void naviSection() {
		navig.click();
	}
	public void naviunanswer() {
		naviunas.click();
	}
	public void navimarkfr() {
		navimark.click();
	}
	public boolean verifytext() {
		return verifytext.isDisplayed();
	}
	public void practiceTest() {
		clickpractie.click();
	}
	public boolean validpracticeTest() {
		return validpract.isDisplayed();
	}
	public void selectPractice(String value) {
		Select dropdw=new Select(clickpract);
		dropdw.selectByValue(value);
	}
	public void createPracticeTest() {
		createe.click();
		checktext.isDisplayed();
	}
	public void clickpracticetest() throws InterruptedException {
		Thread.sleep(20000);
		clickButton.click();
	}
	public Boolean asses_negError() {
		savebtn.click();
		return errorText.isDisplayed();
	}
	public Boolean asses_negunselectError() {
		checkunselect.click();
		return errorText.isDisplayed();
	}
}

package Codem.resources;

import java.io.FileInputStream;
import java.util.Properties;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class Extendreporterng {

	public static ExtentReports getReportObject() {
		System.out.println("hello");
		String path=System.getProperty("user.dir")+"//reportss/index.html";	
//	    String path=System.getProperty("/Users/ramki/eclipse-workspace/RubriksAutomation/report/index.html");
		ExtentSparkReporter report= new ExtentSparkReporter(path);
		report.config().setReportName("Selnium report");
		report.config().setDocumentTitle("Test Results");
	    ExtentReports extend= new ExtentReports();
		extend.attachReporter(report);
		extend.setSystemInfo("Tester", "Jeeva");
		extend.createTest(path);
		return extend;
	}
	
	
	
}

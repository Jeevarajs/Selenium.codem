package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.authDash;
import Codemin.authQuestion;
import Codemin.loginpage;

public class Authorpage extends testinitilize {

	@DataProvider

	public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
	}

	@Test(dataProvider = "getdata")
	public void Auhot_login(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_Dashboard(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		boolean check = author.authdash_recent();
		Assert.assertTrue(check, "Questions created by user in last 30 days");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_Dashboardvalid(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		boolean check1 = author.authdash_recent30();
		Assert.assertTrue(check1, "Recent Questions");
	}

	@Test(dataProvider = "getdata")
	public void Auhot_DashboardQues(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		author.authdash_qsClick();
		boolean check = author.authDas_qsclickvalid();
		Assert.assertTrue(check, "Create Questions");
	}

	@Test(dataProvider = "getdata")
	public void Auhot_DashboardEditQues(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		author.authdash_qsClick();
		author.authdash_qsClickedit();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_DashboardEditQues_pub(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		author.authdash_qsClick();
		author.authdash_qsClickedit();
		author.authdash_qsClickeditpublish();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_DashboardEditQues_createnew(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash author = new authDash(driver);
		author.authdash_qsClick();
		author.authdash_qsClickedit();
		author.authdash_qsClickeditcreat();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_Dashboardpag(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.pagnavigation();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_DashboardpagNavi(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.pagnaviget("color");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_Dashboardscroll(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		driver.manage().window().maximize();
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("scrollBy(0,10000);");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, Keys.END);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestion(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		boolean check = author.authcreateQuestion();
		Assert.assertTrue(check);
		boolean check1 = author.containsfrcreateqs();
		Assert.assertTrue(check1);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMULTI(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee2"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionNUMERIC(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee3"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionNUMERICEdito(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee3"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionNUMtype(input.get("question"), input.get("numans1"), input.get("numans2"),
				input.get("numans3"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMULTI_editor(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee2"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));
	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ_editor(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));
	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ_editorvalidation(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));
		author.tagclick(input.get("Tagname"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ_editQuest(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));
		author.tagclick(input.get("Tagname"));
		author.authcreatequestionedit();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ_newQuest(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));
		author.tagclick(input.get("Tagname"));
		author.authcreatequestioncreatenw();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestionMCQ_hint(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.authcreateQuestion();
		author.authcreateQuestionMcq(input.get("class"), input.get("Subject"), input.get("qstypee"),
				input.get("Scores"), input.get("topiCs"), input.get("Subtopics"), input.get("semantics"),
				input.get("diffiCul"), input.get("Tagname"));
		author.hint(input.get("Tagname"));
		author.authcreateQuestionmcqtype(input.get("question"), input.get("answer1"), input.get("answer2"),
				input.get("answer3"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_managequestion(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		boolean check4 = author.manage_valid();
		Assert.assertTrue(check4, "Manage Questions");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_managequestionSear(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manage_editnav(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));
		author.manage_edit();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manage_editnavvalid(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		// authDash author1=new authDash(driver);
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));
		author.manage_edit();
		boolean check = author.checkasser();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manage_allquestionfilter(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));
		author.manage_allquestion();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manage_savedquestionfilter(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));
		author.manage_savedquestion();
	}

	@Test(dataProvider = "getdata")
	public void Auhot_manage_duplicatequestionfilter(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion author = new authQuestion(driver);
		author.manageqs();
		author.manage_claass(input.get("class"), input.get("Subject"));
		author.manage_duplicatquestion();
	}

}

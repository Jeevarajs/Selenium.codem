package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.ManageQuestionpaper;
import Codemin.Questionpaperpage;
import Codemin.loginpage;

public class instructorTest extends testinitilize {

	@DataProvider

	public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };

	}

	@Test(dataProvider = "getdata")
	public void login(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));

	}

	@Test(dataProvider = "getdata")
	public void loginwithValidation(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		String name = driver
				.findElement(By.xpath("//nav[@class='flex flex-1 hidden w-full h-16 space-x-1 md:flex px-10']"))
				.getText();
		Assert.assertEquals(name, name);

	}

	@Test(dataProvider = "getdata")

	public void createQuest(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));

	}

	@Test(dataProvider = "getdata")

	public void createQuestGen(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionGen("Easy", "100");

	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");

	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySect(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		boolean check = createQuestionpaper.CreateMulti_verifySection();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySectAdd(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		createQuestionpaper.CreateMulti_verifySection();
		boolean check = createQuestionpaper.CreateMulti_SectionADD();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySubsect(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		createQuestionpaper.CreateMulti_verifySection();
		boolean check = createQuestionpaper.CreateMulti_SectionADD();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySub12(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		createQuestionpaper.CreateMulti_verifySection();
		createQuestionpaper.sectionfieldSec(input.get("valueSec"), input.get("valueSecti"));
		createQuestionpaper.sectionfield(input.get("value04"), input.get("value01"), input.get("value02"),
				input.get("value03"));
		createQuestionpaper.sectionfield(input.get("value05"), input.get("value01"), input.get("value02"),
				input.get("value03"));

	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySub12Delete(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		createQuestionpaper.CreateMulti_verifySection();
		createQuestionpaper.sectionfieldSec(input.get("valueSec"), input.get("valueSecti"));
		createQuestionpaper.sectionfield(input.get("value04"), input.get("value01"), input.get("value02"),
				input.get("value03"));
		createQuestionpaper.sectionfield(input.get("value05"), input.get("value01"), input.get("value02"),
				input.get("value03"));
		createQuestionpaper.subsectiondeletedbtn();
	}

	@Test(dataProvider = "getdata")
	public void createMultisubQues_verifySection12Delete(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateMulti("sd", "dsf", "04", "11", "true");
		createQuestionpaper.CreateMulti_verifySection();
		createQuestionpaper.sectionfieldSec(input.get("valueSec"), input.get("valueSecti"));
		createQuestionpaper.sectionfield(input.get("value04"), input.get("value01"), input.get("value02"),
				input.get("value03"));
		createQuestionpaper.sectionfield(input.get("value05"), input.get("value01"), input.get("value02"),
				input.get("value03"));
		createQuestionpaper.sectiondeletedbtn();
	}

	@Test(dataProvider = "getdata")
	public void createquesgen2(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionGen("Easy", "50");
		createQuestionpaper.QuestionGen1("Medium", "");

	}

	@Test(dataProvider = "getdata")
	public void createquesgen3(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionGen("Easy", "25");
		createQuestionpaper.QuestionGenn("Medium", "");
		createQuestionpaper.QuestionGenn("Hard", "");
		createQuestionpaper.QuestionGen1("Very Hard", "");

	}

	@Test(dataProvider = "getdata")
	public void createqueSemant(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionSemantics("Remember", "100");

	}

	@Test(dataProvider = "getdata")
	public void createqueSemant2(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionSemantics1("Understand", "50");
		createQuestionpaper.QuestionSemantics("Remember", "");

	}

	@Test(dataProvider = "getdata")
	public void createqueSemant3(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionSemantics1("Understand", "25");
		createQuestionpaper.QuestionSemantics2("Remember", "");
		createQuestionpaper.QuestionSemantics2("Apply", "");
		createQuestionpaper.QuestionSemantics("Analyze", "");

	}

	@Test(dataProvider = "getdata")
	public void createqueSearch(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbar();

	}

	@Test(dataProvider = "getdata")
	public void createqueSearchaddind(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();

	}

	@Test(dataProvider = "getdata")
	public void createqueSearchPreview(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();
		boolean check = createQuestionpaper.preview();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void createqueSearchPreview_footer(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();
		createQuestionpaper.preview();
		String get = createQuestionpaper.preview_footercontains();
		System.out.println(get);

	}

	@Test(dataProvider = "getdata")
	public void checkUsercan_AlsoPUBLISH_preview(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();
		createQuestionpaper.preview();
		String get = createQuestionpaper.preview_footercontains();
		System.out.println(get);
		createQuestionpaper.previewPage_publish();

	}

	@Test(dataProvider = "getdata")
	public void checkUsercan_AlsoPUBLISH_MODALcontains(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalques"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();
		createQuestionpaper.preview();
		String get = createQuestionpaper.preview_footercontains();
		System.out.println(get);
		createQuestionpaper.previewPage_publish();
		boolean check = createQuestionpaper.publishpage_modalCONTAINS();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void checkUsercan_PREVIEWPAGE_edit(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalques"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchbarind();
		createQuestionpaper.preview();
		createQuestionpaper.preview_footercontains();
		createQuestionpaper.previewpage_edit();

	}

	@Test(dataProvider = "getdata")
	public void popvalidcreaq(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.poptextvalid();

	}

	@Test(dataProvider = "getdata")
	public void submitques(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalques"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.creatqspop();

	}

	@Test(dataProvider = "getdata")
	public void creatingnew(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.Createnew(input.get("qstypee"), input.get("Scores"), input.get("topiCs"),
				input.get("Subtopics"), input.get("semantics"), input.get("diffiCul"), input.get("Tagname"),
				input.get("question"), input.get("ans1"), input.get("ans2"), input.get("ans3"));

	}

	@Test(dataProvider = "getdata")
	public void checkAddques(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.addedqs();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithEMpty(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.manage_view();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_AssignPAGE(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.manage_view();
		manageQuestionpaper.manage_assignbutton();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_publishPAGE(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.manage_view();
		manageQuestionpaper.manage_publishbutton();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithfiletr(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.Manageqspape(input.get("classn"));
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
		manageQuestionpaper.Manageqspapedate(input.get("Date"));
		manageQuestionpaper.manage_view();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithfiletr1(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.Manageqspape(input.get("classn"));
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
		manageQuestionpaper.Manageqspapedate(input.get("Date"));
		manageQuestionpaper.manage_todated(input.get("todate"));
		manageQuestionpaper.manage_view();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithfiletr_changetodate(HashMap<String, String> input)
			throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.Manageqspape(input.get("classn"));
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
		manageQuestionpaper.Manageqspapedate(input.get("Date"));
		manageQuestionpaper.manage_todated(input.get("todate1"));
		manageQuestionpaper.manage_view();

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithfiletr_changetodatetopast(HashMap<String, String> input)
			throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.Manageqspape(input.get("classn"));
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
		manageQuestionpaper.Manageqspapedate(input.get("Date"));
		manageQuestionpaper.manage_todated(input.get("todate2"));
		manageQuestionpaper.manage_view();
		boolean check = manageQuestionpaper.manage_validationtoDate();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")

	public void manageQuest_viewwithfiletr_givetodateto(HashMap<String, String> input)
			throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.Manageqspape(input.get("classn"));
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
		manageQuestionpaper.manage_todated(input.get("todate2"));
		manageQuestionpaper.manage_view();
		boolean check = manageQuestionpaper.manage_validationtoDate();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")

	public void manageQuest(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		String name = manageQuestionpaper.Valid();
		System.out.println(name);
		Assert.assertTrue(true, name);

	}

	@Test(dataProvider = "getdata")

	public void manageQuestEdit(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.managevalidedit();
	}

	@Test(dataProvider = "getdata")

	public void manageQuest_filterclass(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspape(input.get("classn"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuest_filtersub(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.ManageqspapeSub(input.get("value"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuest_filterdate(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspapedate(input.get("Date"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestpublishbtn(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.publishAsASSIGN();
	}

	@Test(dataProvider = "getdata")

	public void manageQuestAssignpage(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.assignpage(input.get("testnam"), input.get("instruction"));
	}

	@Test(dataProvider = "getdata")

	public void manageTest(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
	}

	@Test(dataProvider = "getdata")

	public void manageTest_AllFilter(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
		manageQuestionpaper.testpageAll();
	}

	@Test(dataProvider = "getdata")

	public void manageTest_openFilter(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
		manageQuestionpaper.testpageopen();
	}

	@Test(dataProvider = "getdata")

	public void manageTest_closedFilter(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
		manageQuestionpaper.testpageclosed();
	}

	@Test(dataProvider = "getdata")

	public void manageTest_scdhuleFilter(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
		manageQuestionpaper.testpagescdhule();
	}

	@Test(dataProvider = "getdata")

	public void manageTest_mytestFilter(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.testpage();
		manageQuestionpaper.testpagemytest();
	}

}

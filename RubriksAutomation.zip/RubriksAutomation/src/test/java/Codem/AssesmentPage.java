package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.assesmentpage;
import Codemin.loginpage;

public class AssesmentPage extends testinitilize {

	@DataProvider

	public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
	}

	 @Test(dataProvider="getdata")
	public void Sturdent_login(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
		

	}

	

	 @Test(dataProvider="getdata")
	public void Sturdent_taketest(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
		assesmentpage AssesmentPage = new assesmentpage(driver);
		AssesmentPage.assesm_testAssig();

	}
	 @Test(dataProvider="getdata")
		public void Sturdent_cauroseldetails(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplicationAssesment();
			login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
			assesmentpage AssesmentPage = new assesmentpage(driver);
			AssesmentPage.cauroseldetails();

		}
	@Test(dataProvider="getdata")
		public void Sturdent_moreinfovalid(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplicationAssesment();
			login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
			assesmentpage AssesmentPage = new assesmentpage(driver);
			AssesmentPage.assesm_testAssig();
			AssesmentPage.assesm_moreinfo();
	       boolean check= AssesmentPage.moreinfovalidation();

		}
	 @Test(dataProvider="getdata")
	public void Sturdent_taketes(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplicationAssesment();
		login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
		assesmentpage AssesmentPage = new assesmentpage(driver);
		AssesmentPage.assesm_testAssig();
		AssesmentPage.assesm_taketest();

	}
	@Test(dataProvider="getdata")
	public void Sturdent_taketesStart(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplicationAssesment();
		login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
		assesmentpage AssesmentPage = new assesmentpage(driver);
		AssesmentPage.assesm_testAssig();
		AssesmentPage.assesm_moreinfo();


	}
	 @Test(dataProvider="getdata")
		public void Sturdent_taketesandStart(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplicationAssesment();
			login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
			assesmentpage AssesmentPage = new assesmentpage(driver);
			AssesmentPage.assesm_testAssig();
			AssesmentPage.assesm_taketest();
			AssesmentPage.assesm_starttest();


		}

	
	



	
	@Test(dataProvider="getdata")
		public void Sturdent_myTest(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplication();
			login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
			assesmentpage AssesmentPage = new assesmentpage(driver);
			AssesmentPage.assesm_MyTest();
			boolean check=AssesmentPage.mytestcontains();
			Assert.assertTrue(check);

		}
		 @Test(dataProvider="getdata")
				public void Sturdent_validatemyTestpage(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					boolean check=AssesmentPage.assesm_validatemytest();
					Assert.assertTrue(check, "My Test");

				}
				 @Test(dataProvider="getdata")
				public void Sturdent_validatemycTestpage(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
                    boolean checkdata=AssesmentPage.assesm_mytest_Ctest();
					Assert.assertTrue(checkdata);				     

				}
				 @Test(dataProvider="getdata")
				public void Sturdent_validatemycTestpageTaketest(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
     				AssesmentPage.assesm_taketest();
     			
     				

				}
			
				
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentpagAll(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplicationAssesment();
					login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					boolean checkd=AssesmentPage.assesm_instruction();
					Assert.assertTrue(checkd, "Instruction");
					

 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_validatemycTestpageCheConinue(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
     				AssesmentPage.assesm_taketest();
                    AssesmentPage.assesm_continuebutton();
 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_validatemycTestpgeCheConinue(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					driver.manage().window().maximize();
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
                  AssesmentPage.assesm_continuebutton();
                  boolean value=	AssesmentPage.assesm_titleofpage();
				Assert.assertFalse(value);
 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_validatemycTestpageCheConiue(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
                AssesmentPage.assesm_continuebutton();
			
				
 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_Assesmentpage(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_continuetest();
					Thread.sleep(3000);
					AssesmentPage.assesm_unanswerbtn();
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentpageMark(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
                   	AssesmentPage.assesm_CONTtest();
					Thread.sleep(4000);
					AssesmentPage.assesm_markfrREview();

 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmetpagAll(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					AssesmentPage.assesm_alltest();

 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentpaAll(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					driver.manage().window().maximize();
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(3000);
                    AssesmentPage.assesm_answer();

 
				}
			 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentagAll(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(3000);
					AssesmentPage.assesm_answer1();

 
				}

				 @Test(dataProvider="getdata")
				public void Sturdent_Assesmentpanextslide(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.assesm_nextbtnslide();
					Thread.sleep(4000);

 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_Assesmentpabackslide(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.assesm_nextbtnslide();
                    Thread.sleep(3000);
					AssesmentPage.assesm_backbtnslide();
					Thread.sleep(4000);


 
				}
				
				 @Test(dataProvider="getdata")
				public void Sturdent_Assesmentpa(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.susection();

 
				}
				@Test(dataProvider="getdata")
				public void Sturdent_Assesmentpagination(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.pagination();

 
				}
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentSubmit(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.submitbtn();

 
				}
				 @Test(dataProvider="getdata")
					public void Sturdent_AssesmentSubmitConfirmNo(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
						AssesmentPage.assesm_taketest();
						AssesmentPage.assesm_CONTtest();
						Thread.sleep(5000);
						AssesmentPage.submitbtn();
						AssesmentPage.nobtn();

	 
					}
				 @Test(dataProvider="getdata")
					public void Sturdent_AssesmentSubmitpage_navigate(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
						AssesmentPage.assesm_taketest();
						AssesmentPage.assesm_CONTtest();
						Thread.sleep(5000);
						AssesmentPage.submitbtn();
						AssesmentPage.naviSection();

	 
					}
				 @Test(dataProvider="getdata")
					public void Sturdent_AssesmentSubmitpage_navigatemark(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
						AssesmentPage.assesm_taketest();
						AssesmentPage.assesm_CONTtest();
						Thread.sleep(5000);
						AssesmentPage.submitbtn();

						AssesmentPage.navimarkfr();

	 
					}
					@Test(dataProvider="getdata")
					public void Sturdent_AssesmentSubmitpage_navigateunans(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
						AssesmentPage.assesm_taketest();
						AssesmentPage.assesm_CONTtest();
						Thread.sleep(5000);
						AssesmentPage.submitbtn();
                        AssesmentPage.naviunanswer();

	 
					}
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentSubmitConfirm(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.submitbtn();
					AssesmentPage.yesbtn();

 
				}
				 @Test(dataProvider="getdata")
					public void Sturdent_validatemycTestpageresult(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
	                    AssesmentPage.assesm_mytestpage_validateresult();
					}
					 @Test(dataProvider="getdata")
					public void Sturdent_validatemycTestpageresultpage(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
	                    AssesmentPage.assesm_mytestpage_clickresult();
	                    
	                    
	                    
					}
					 @Test(dataProvider="getdata")
					public void Sturdent_validatemycTestpageCheckresultpage(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail4"), input.get("assespassword4"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_MyTest();
	                    AssesmentPage.assesm_mytestpage_clickresult();
	                    Thread.sleep(5000);
	                    boolean check=AssesmentPage.assesm_showResultpage();
	                    Assert.assertTrue(check);
					}
					 @Test(dataProvider="getdata")
						public void Sturdent_AssesmentUnSelect(HashMap<String, String> input) throws IOException, InterruptedException {

							loginpage login = launchapplication();
							login.instructorlogin(input.get("assesemail3"), input.get("assespassword3"));
							assesmentpage AssesmentPage = new assesmentpage(driver);
							AssesmentPage.assesm_MyTest();
							AssesmentPage.assesm_taketest();
							AssesmentPage.assesm_starttest();
							boolean check=AssesmentPage.assesm_UnSelectBtn();
							Assert.assertTrue(check);
						

						}
					 @Test(dataProvider="getdata")
						public void Sturdent_AssesmentUnSelectValida(HashMap<String, String> input) throws IOException, InterruptedException {

							loginpage login = launchapplication();
							login.instructorlogin(input.get("assesemail3"), input.get("assespassword3"));
							assesmentpage AssesmentPage = new assesmentpage(driver);
							AssesmentPage.assesm_MyTest();
							AssesmentPage.assesm_taketest();
							AssesmentPage.assesm_CONTtest();
							AssesmentPage.assesm_unselect();
							boolean check=AssesmentPage.asses_negunselectError();
							Assert.assertTrue(check);
						
						}
					 @Test(dataProvider="getdata")
						public void Sturdent_AssesmentUnSelectinMarkFReview(HashMap<String, String> input) throws IOException, InterruptedException {

							loginpage login = launchapplication();
							login.instructorlogin(input.get("assesemail3"), input.get("assespassword3"));
							assesmentpage AssesmentPage = new assesmentpage(driver);
							AssesmentPage.assesm_MyTest();
							AssesmentPage.assesm_taketest();
							AssesmentPage.assesm_CONTtest();
							Thread.sleep(5000);
							AssesmentPage.verifyMarkfrReview();
						
						}
				
			
				 @Test(dataProvider="getdata")
				public void Sturdent_AssesmentSubmitConfirmVerify(HashMap<String, String> input) throws IOException, InterruptedException {

					loginpage login = launchapplication();
					login.instructorlogin(input.get("assesemail3"), input.get("assespassword3"));
					assesmentpage AssesmentPage = new assesmentpage(driver);
					AssesmentPage.assesm_MyTest();
					AssesmentPage.assesm_taketest();
					AssesmentPage.assesm_CONTtest();
					Thread.sleep(5000);
					AssesmentPage.submitbtn();
					AssesmentPage.yesbtn();
					boolean text=AssesmentPage.verifytext();
					Assert.assertTrue(text, "Congratulations! Your test has been submitted");

 
				}
				 
				
				
				
				 @Test(dataProvider="getdata")
					public void Sturdent_Dashboard(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_Dashboard();

					}

					 @Test(dataProvider="getdata")
					public void Sturdent_recnt(HashMap<String, String> input) throws IOException, InterruptedException {

						loginpage login = launchapplication();
						login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
						assesmentpage AssesmentPage = new assesmentpage(driver);
						AssesmentPage.assesm_recentscore();

					}




}

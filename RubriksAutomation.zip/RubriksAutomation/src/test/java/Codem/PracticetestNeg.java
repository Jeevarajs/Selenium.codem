package Codem;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.assesmentpage;
import Codemin.loginpage;

public class PracticetestNeg extends testinitilize{

	@DataProvider

public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
}
     //  @Test(dataProvider="getdata")
		public void Asses_login(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplication();
			login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
			

		}
		 
		 @Test(dataProvider="getdata")
			public void Sturdent_AssesmentPracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();
				boolean check=AssesmentPage.checkfrpract();
				AssertJUnit.assertFalse(false);

			}
		 //@Test(dataProvider="getdata")
			public void Sturdent_takeStarttesT(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail1"), input.get("assespassword1"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.assesm_testAssig();
				AssesmentPage.assesm_taketest();
				AssesmentPage.assesm_takeTEST();
				Thread.sleep(5000);
				Boolean check=AssesmentPage.asses_negError();
				System.out.println(check);

			}
			//@Test(dataProvider="getdata")
			public void pract_unselectErrorvalidation(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail1"), input.get("assespassword1"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.assesm_testAssig();
				AssesmentPage.assesm_taketest();
				AssesmentPage.assesm_takeTEST();
				Thread.sleep(5000);
				boolean check=AssesmentPage.asses_negunselectError();
				System.out.println(check);
			}
			//@Test(dataProvider="getdata")
			public void pract_markfrselectErrorvalidation(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail1"), input.get("assespassword1"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.assesm_testAssig();
				AssesmentPage.assesm_taketest();
				AssesmentPage.assesm_takeTEST();
				Thread.sleep(5000);
				boolean check=AssesmentPage.verifymarkfrthrowError();
				System.out.println(check);
			}
			
		
				
}


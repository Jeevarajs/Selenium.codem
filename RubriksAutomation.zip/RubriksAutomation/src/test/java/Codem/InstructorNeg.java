package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.ManageQuestionpaper;
import Codemin.Questionpaperpage;
import Codemin.assesmentpage;
import Codemin.loginpage;

public class InstructorNeg extends testinitilize {

	@DataProvider

	public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
	}

	@Test(dataProvider = "getdata")
	public void Sturdent_takeStarttesT(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorloginN();
		boolean check = login.empty();
		Assert.assertTrue(check, "Email is required to Sign In");
		boolean check1 = login.Empty();
		Assert.assertTrue(check1, "Password is required to Sign In");

	}

	@Test(dataProvider = "getdata")
	public void Asses_login1(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("emailN"), input.get("passwordN"));
		boolean check = login.invalid();
		Assert.assertTrue(check, "Invalid Credentials");

	}

	@Test(dataProvider = "getdata")
	public void Asses_createQswithEmptydata(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		boolean check = createQuestionpaper.instNeg_emptyfield();
		Assert.assertTrue(check, "Question paper name is required");

	}

	@Test(dataProvider = "getdata")
	public void Asses_createQswithEmptywithtotalQs(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.instNeg_totalnumscore(input.get("Quespapname"), input.get("class"), input.get("MultiSub"),
				input.get("Subject"), input.get("Tagname"));
		createQuestionpaper.instNeg_validationCheck();

	}

	@Test(dataProvider = "getdata")
	public void Asses_ChecktotalqsandSectionTotal(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.instNeg_totalqsCheckWithSection(input.get("Quespapname"), input.get("Tagname"),
				input.get("totalques"), input.get("class"), input.get("MultiSub1"), input.get("value1"),
				input.get("value2"));
		boolean check = createQuestionpaper.instNeg_validateExceed();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckDifficultyEmpty(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.instNeg_difficultyEmpty();
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckDifficultyhard_valueEmpty(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.instNeg_difficultyhardvalue(input.get("diffiCul"));
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckDifficultyhardInvalidCheck(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionGen(input.get("diffiCul"), input.get("invalidvalue"));
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSemanticEmpty(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.instNeg_checkSeman();
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSemanticEmptyvalue(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.instneg_semanticsvalueEmpty(input.get("semantics"));
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSemanticinvalidvale(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.QuestionSemantics1(input.get("semantics"), input.get("invalidvalue"));
		boolean check = createQuestionpaper.instNeg_validationFRdifficul();
		Assert.assertTrue(check);
	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSearbarshowvalidation(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.searchba();

	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSearbarwrongvalue(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		boolean check = createQuestionpaper.stringempty();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void Asses_CheckSearbaraddquestionEmpty(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.poptextvalid();

	}

	@Test(dataProvider = "getdata")
	public void creatingnew_validate(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.indvalidNeg();

	}

	@Test(dataProvider = "getdata")
	public void addedqs_validate(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.indvalidNeg();
		createQuestionpaper.addedqs();

	}

	@Test(dataProvider = "getdata")
	public void notest_validate(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.testpagemytest();

	}

	@Test(dataProvider = "getdata")
	public void dasboardnotest_validate(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		boolean check = createQuestionpaper.validatenotest();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void createqs_validate(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("email"), input.get("password"));
		Thread.sleep(2000);
		Questionpaperpage createQuestionpaper = new Questionpaperpage(driver);
		createQuestionpaper.CreateQuestion(input.get("Quespapname"), input.get("Tagname"), input.get("totalscore"),
				input.get("class"), input.get("MultiSub"), "Biology", input.get("totalscore"));
		createQuestionpaper.createqswithoutqs(input.get("qstypee"), input.get("Scores"), input.get("topiCs"),
				input.get("Subtopics"), input.get("semantics"), input.get("diffiCul"), input.get("Tagname"));

		createQuestionpaper.createqsValidation(input.get("Tagname"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestAssignpage(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.instneg_assignpage(input.get("instruction"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestinsAssignpage(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.instneg_withoutsec(input.get("testnam"), input.get("instruction"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestinsgnpage(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.instneg_withoutinstr(input.get("testnam"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestinsgnpagwithutdate(HashMap<String, String> input) throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.instNeg_withoutdate(input.get("testnam"), input.get("instruction"));
	}

	@Test(dataProvider = "getdata")

	public void manageQuestinsgnpagwithutTOdate(HashMap<String, String> input)
			throws IOException, InterruptedException {
		loginpage login = launchapplication();
		login.instructorlogin(input.get("instemail"), input.get("instpassword"));
		Thread.sleep(2000);
		ManageQuestionpaper manageQuestionpaper = new ManageQuestionpaper(driver);
		manageQuestionpaper.Manageqspaper();
		manageQuestionpaper.instNeg_withoutTOdate(input.get("testnam"), input.get("instruction"));
	}

}

package Codem.testcomponent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codemin.loginpage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class testinitilize {
public WebDriver driver;

	public WebDriver initializebrowser() throws IOException {
		
		Properties prop=new Properties();
		FileInputStream fis=new FileInputStream("/Users/ramki/eclipse-workspace/RubriksAutomation/src/main/java/Codem/resources/globaldata.properties");
		prop.load(fis);
		String browsername=prop.getProperty("browser");
		if(browsername.equalsIgnoreCase("chrome")) {
		WebDriverManager.chromedriver().setup();
		 driver =new ChromeDriver();
		}
		else {
			System.out.println("browserfails");
		}
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 driver.manage().window().maximize();
		 return driver;
		 
	}
	
	
	public loginpage launchapplication() throws IOException {
		driver= initializebrowser();
        loginpage login=new loginpage(driver);
		login.loadUrl();
		return login;
	}
	public loginpage launchapplicationAssesment() throws IOException {
		driver= initializebrowser();
        loginpage login=new loginpage(driver);
		login.loadUrlAsses();
		return login;
	}
	public String getScreenshot(String testCaseName,WebDriver driver) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File file = new File(System.getProperty("user.dir") + "//reports//" + testCaseName + ".png");
		FileUtils.copyFile(source, file);
		return System.getProperty("user.dir") + "//reports//" + testCaseName + ".png";
		
		
	}
	@AfterMethod
	public void close() {
		driver.quit();
	}
	public List<HashMap<String, String>> getdatajson(String filepath) throws IOException {
		String jsoncontent=FileUtils.readFileToString(new File(filepath),
				StandardCharsets.UTF_8);
	
	ObjectMapper mapper= new ObjectMapper();
	  List<HashMap<String, String>> data = mapper.readValue(jsoncontent, new TypeReference<List<HashMap<String, String>>>() {
		  
	  });	
	
	return data;
	
	}

}

package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.assesmentpage;
import Codemin.loginpage;

public class Practicetest extends testinitilize{

	@DataProvider

public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
}
       @Test(dataProvider="getdata")
		public void Asses_login(HashMap<String, String> input) throws IOException, InterruptedException {

			loginpage login = launchapplication();
			login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
			

		}
		 
		 @Test(dataProvider="getdata")
			public void Sturdent_AssesmentPracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();


			}
			// @Test(dataProvider="getdata")
			public void Sturdent_AssesmentvalidPracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();
				boolean check1=AssesmentPage.validpracticeTest();
				Assert.assertTrue(check1, "Practice Test");


			}
		//	 @Test(dataProvider="getdata")
			public void Sturdent_AssesmentSelectPracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();
				AssesmentPage.selectPractice(input.get("Jee"));


			}
			// @Test(dataProvider="getdata")
			public void Sturdent_AssesmentSelectCreatePracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();
				AssesmentPage.selectPractice(input.get("Jee"));
				AssesmentPage.createPracticeTest();

			}
			@Test(dataProvider="getdata")
			public void Sturdent_AssesmentSelect_Create_ClickPracticeTestPage(HashMap<String, String> input) throws IOException, InterruptedException {

				loginpage login = launchapplication();
				login.instructorlogin(input.get("assesemail"), input.get("assespassword"));
				assesmentpage AssesmentPage = new assesmentpage(driver);
				AssesmentPage.practiceTest();
				AssesmentPage.selectPractice(input.get("Jee"));
				AssesmentPage.createPracticeTest();
				AssesmentPage.clickpracticetest();

			}
		
				
}


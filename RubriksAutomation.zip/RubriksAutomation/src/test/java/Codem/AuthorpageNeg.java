package Codem;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Codem.testcomponent.testinitilize;
import Codemin.authDash;
import Codemin.authQuestion;
import Codemin.loginpage;

public class AuthorpageNeg extends testinitilize {

	@DataProvider

	public Object[] getdata() throws JacksonException, IOException, IOException {
		HashMap<String, Object> map = new ObjectMapper().readValue(new File(
				"/Users/ramki/eclipse-workspace/RubriksAutomation/src/test/java/Codem/data/questionpaperdata.json"),
				new TypeReference<HashMap<String, Object>>() {
				});
		return new Object[] { map };
	}

	@Test(dataProvider = "getdata")
	public void Auhot_loginWithEmptyData(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorloginN();
		boolean check = login.empty();
		Assert.assertTrue(check, "Email is required to Sign In");
		boolean check1 = login.Empty();
		Assert.assertTrue(check1, "Password is required to Sign In");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_loginwithInvalidData(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authNemail"), input.get("authNpassword"));
		boolean check = login.invalid();
		Assert.assertTrue(check, "Invalid Credentials");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_login_verifyUrl(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash authorneg = new authDash(driver);
		authorneg.authNeg_editverify();
		String check = authorneg.authNeg_verifyUrl();
		Assert.assertEquals(check, input.get("VERIFYURL"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_login_verify(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash authorneg = new authDash(driver);
		String check = authorneg.logoClick();
		Assert.assertEquals(check, "Dashboard");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_login_hoverMenu(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash authorneg = new authDash(driver);
		authorneg.authneg_hover();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_login_clickLogo_Check(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash authorneg = new authDash(driver);
		String check = authorneg.logoClick();
		Assert.assertEquals(check, "Dashboard");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_login_hoverMenuGettext(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authDash authorneg = new authDash(driver);
		String name = authorneg.authneg_hoverContains();
		System.out.println(name);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_createquestWith_Emptydata(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		boolean check = authorneg.authneg_errorempty();
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_Selectsubject_withoutclass(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authNeg_emptydataError();
		String name = authorneg.authneg_clicksubject();
		System.out.println(name);
	}

	@Test(dataProvider = "getdata")
	public void Auhot_ScorefieldNotallow_Alpha(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authneg_checkscorefield("e");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_ScorefieldNotallow_special(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		boolean check = authorneg.authneg_checkscorefield(input.get("special"));
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_ScorefieldNotallow_alphanumer(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		boolean check = authorneg.authneg_checkscorefield(input.get("alphanumeric"));
		Assert.assertTrue(check);

	}

	@Test(dataProvider = "getdata")
	public void Auhot_tagfieldallow_Alpha(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authneg_tagsalpha(input.get("alpha"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_tagfieldallow_special(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authneg_tagsalpha(input.get("special"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_tagfieldallow_alphanumeric(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authneg_tagsalpha(input.get("alphanumeri"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_tagfieldallow_TABkey(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.authneg_createQuestion();
		authorneg.authneg_tagsalpha(input.get("alphanumeri"));

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithEmpty(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();
		authorneg.authneg_manageEmptydata();

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithEmptysubject(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();
		authorneg.authneg_checkmanagaEmpty(input.get("class"));
		boolean check = authorneg.authneg_manageEmptydata();
		Assert.assertTrue(check, "Please Enter a class & Subject");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithEmptyclass(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();
		authorneg.authneg_checkmanagaEmptyclass(input.get("subject"));
		boolean check = authorneg.authneg_manageEmptydata();
		Assert.assertTrue(check, "Please Enter a class & Subject");

	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithfilter(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();
		authorneg.authneg_checkwithfilter(input.get("class"), input.get("subject"));
		Thread.sleep(2000);
		boolean check = authorneg.authneg_noquestionvalidation();
		Assert.assertTrue(check, "No Question");
	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithrefresh(HashMap<String, String> input) throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();

		authorneg.authneg_checkwithfilter(input.get("class"), input.get("Subject"));

		authorneg.manageqs();
	}

	@Test(dataProvider = "getdata")
	public void Auhot_manageSearchwithfilterDifficulty(HashMap<String, String> input)
			throws IOException, InterruptedException {

		loginpage login = launchapplication();
		login.instructorlogin(input.get("authemail"), input.get("authpassword"));
		authQuestion authorneg = new authQuestion(driver);
		authorneg.manageqs();
		authorneg.authneg_checkwithfilterdifficulty(input.get("class"), input.get("Subject"));
	}

}
